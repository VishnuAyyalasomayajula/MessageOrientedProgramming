package coen6371.as3.consumer;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class Recv {

    private final static String EXCHANGE_NAME = "topic_mongodb";
    private final static String QUEUE_NAME = "order_queue";
    private final static String HOST = "129.146.133.157";
    //private final static int PORT = 5672;

    public static void main(String[] args) {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost(HOST);
        //factory.setPort(PORT);

        try (Connection connection = factory.newConnection();
             Channel channel = connection.createChannel()) {

            channel.exchangeDeclare(EXCHANGE_NAME, "topic");

            // Declare the queue with a fixed name
            channel.queueDeclare(QUEUE_NAME, false, false, false, null);

            String[] bindingKeys = {
                    "Cost-",
                    "Top5-Expensive States-",
                    "Top5-Economic-States",
                    "Top5-HighestGrowthStates for given Year",
                    "AverageExpense-"
            };

            for (String bindingKey : bindingKeys) {
                channel.queueBind(QUEUE_NAME, EXCHANGE_NAME, bindingKey);
            }

            System.out.println(" [*] Waiting for messages. To exit press CTRL+C");

            DeliverCallback deliverCallback = (consumerTag, delivery) -> {
                String message = new String(delivery.getBody(), "UTF-8");
                System.out.println(" [x] Received '" + delivery.getEnvelope().getRoutingKey() + "':'" + message + "'");
                processMessage(delivery.getEnvelope().getRoutingKey(), message);
            };

            channel.basicConsume(QUEUE_NAME, true, deliverCallback, consumerTag -> {});

        } catch (IOException | TimeoutException e) {
            e.printStackTrace(); // Print any exceptions that occur
        }
    }

    private static void processMessage(String routingKey, String message) {
        System.out.println("Processing message from routing key: " + routingKey);
        System.out.println("Message content: " + message);
    }
}
